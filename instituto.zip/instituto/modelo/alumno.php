<?php


class alumno
{

    public $nome;
    public $nota;

    public function __construct($c_nome, $c_nota)
    {
        $this->nome = $c_nome;
        $this->nota = $c_nota;
      

    }

    public function ALTA_BD()
    {
        $connect = new conexion;
        $query = "CREATE TABLE IF NOT EXISTS alumnos(
            cod int not null primary key auto_increment,
            nome varchar(50),
            nota int
        )";
        $connect->con->query($query);
        $connect->con->close();
        echo "<h1> la tabla ha sido creada";
        // $connect->con->query($query);
    }
    public function guardaralumno()
    {
        $connect = new conexion;
        $query = "INSERT INTO `alumnos` (`cod`, `nome`, `nota`) VALUES (NULL, '$this->nome', '$this->nota');";
        $connect->con->query($query);
        $connect->con->close();
        echo "<br>Alta efectuada correctamente para  $this->nome ";
    }

    static function VER_T()
    {

        $obxcon = new Conexion();

        $query = $obxcon->con->query('select * from alumnos');

        $result = array();

        $i = 0;
        while ($fila = $query->fetch_assoc()) {

            $result[$i] = $fila;
            $i++;
        }
        $obxcon->con->close();
        return $result;
    }
    public function buscaralumno()
    {
        $connect = new conexion;
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
  
        // if (!empty($_POST['codigo'])) {
        //     $query = $connect->con->query("SELECT * FROM `alumnos` WHERE `cod` = '$this->cod' ");
          
        // }else {
        //     $query = $connect->con->query("SELECT * FROM `alumnos` WHERE `nome` LIKE '$this->nome%' ");
        // }
        $query = $connect->con->query("SELECT * FROM `alumnos` WHERE `nome` LIKE '$this->nome%' ");

        $result = array();
        $i = 0;
        while ($fila = $query->fetch_assoc()) {
            $result[$i] = $fila;
            $i++;
        }
        $connect->con->close();
        return $result;
    }

    public function eliminar()
    {
        $connect = new conexion;
        $query = "DELETE FROM alumnos WHERE `nome` = '$this->nome'";
        $connect->con->query($query);
        $connect->con->close();

    }

    public function modificar($c)
    {
        $connect = new conexion;
        $query = "UPDATE `alumnos` SET nome = '$this->nome', nota = '$this->nota' WHERE cod = '$c'";
        $connect->con->query($query);
        $connect->con->close();
        // header("Refresh:0; url=index.php?ctr=C_alumno&act=alta");
        // exit;
    echo " <meta http-equiv=refresh content=0;url=index.php?ctr=C_alumno&act=ver_t /> ";   
    
    }
}


