<?php

class matricula
{
    public $alumno;
    public $modulo;

    public function __construct($c_nome, $c_mod)
    {
        $this->alumno = $c_nome;
        $this->modulo = $c_mod;
    }
    public function ALTA_BD()
    {
        $connect = new conexion;
        $query = "CREATE TABLE IF NOT EXISTS matricula(
            cod int not null  auto_increment,
            alumno int,
            modulo int,
            primary key (cod),
            constraint foreign key (alumno) references alumnos(cod) on delete cascade,
            constraint foreign key (modulo) references modulos(cod) on delete cascade
        )";
        $connect->con->query($query);
        $connect->con->close();
        echo "<h1> la tabla ha sido creada";
        // $connect->con->query($query);
    }

    public function matricular()
    {
        $connect = new conexion;
        $query = "INSERT INTO `matricula` (`cod`, `alumno`, `modulo`) VALUES (NULL, '$this->alumno', '$this->modulo');";
        $connect->con->query($query);
        $connect->con->close();
        echo "<br>Alta efectuada correctamente para  $this->alumno ";
    }
    static function VER_T()
    {

        $obxcon = new Conexion();

        // SELECT m.cod ,m.alumno ,m.modulo,a.nome,o.descripcion from matricula m , alumnos a, modulos o WHERE a.cod = m.alumno AND o.cod = m.modulo;

        $query = $obxcon->con->query('select m.cod ,m.alumno ,m.modulo,a.nome,o.descripcion from matricula m , alumnos a, modulos o WHERE a.cod = m.alumno AND o.cod = m.modulo;');

        $result = array();

        $i = 0;
        while ($fila = $query->fetch_assoc()) {

            $result[$i] = $fila;
            $i++;
        }
        $obxcon->con->close();
        return $result;
    }
    public function eliminar()
    {
        $connect = new conexion;
        $query = "DELETE FROM matricula WHERE `cod` = '$this->alumno'";
        $connect->con->query($query);
        $connect->con->close();

    }
    public function modificar($c)
    {
        $connect = new conexion;
        $query = "UPDATE `matricula` SET modulo = '$this->modulo' WHERE cod = '$c'";
        $connect->con->query($query);
        $connect->con->close();
        // header("Refresh:0; url=index.php?ctr=C_matricula&act=ver_t");
        // exit;
        echo " <meta http-equiv=refresh content=0;url=index.php?ctr=C_matricula&act=ver_t /> ";   
    }
}
