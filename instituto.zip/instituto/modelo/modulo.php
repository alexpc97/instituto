<?php


class modulo
{

    public $descripcion;
    public $horas;

    public function __construct($c_nome, $c_nota)
    {
        $this->descripcion = $c_nome;
        $this->horas = $c_nota;
      

    }

    public function ALTA_BD()
    {
        $connect = new conexion;
        $query = "CREATE TABLE IF NOT EXISTS modulos(
            cod int not null primary key auto_increment,
            descripcion varchar(50),
            horas int
        )";
        $connect->con->query($query);
        $connect->con->close();
        echo "<h1> la tabla ha sido creada";
        // $connect->con->query($query);
    }
    public function guardarmodulo()
    {
        $connect = new conexion;
        $query = "INSERT INTO `modulos` (`cod`, `descripcion`, `horas`) VALUES (NULL, '$this->descripcion', '$this->horas');";
        $connect->con->query($query);
        $connect->con->close();
        echo "<br>Alta efectuada correctamente para  $this->descripcion ";
    }

    static function VER_T()
    {

        $obxcon = new Conexion();

        $query = $obxcon->con->query('select * from modulos');

        $result = array();

        $i = 0;
        while ($fila = $query->fetch_assoc()) {

            $result[$i] = $fila;
            $i++;
        }
        $obxcon->con->close();
        return $result;
    }
   

    public function eliminar()
    {
        $connect = new conexion;
        $query = "DELETE FROM modulos WHERE `descripcion` = '$this->descripcion'";
        $connect->con->query($query);
        $connect->con->close();

    }

    public function modificar($c)
    {
        $connect = new conexion;
        $query = "UPDATE `modulos` SET descripcion = '$this->descripcion', horas = '$this->horas' WHERE cod = '$c'";
        $connect->con->query($query);
        $connect->con->close();
        // header("Refresh:0; url=index.php?ctr=C_modulo&act=ver_t");
        // exit;
        echo " <meta http-equiv=refresh content=0;url=index.php?ctr=C_modulo&act=ver_t /> ";   
    }
}

