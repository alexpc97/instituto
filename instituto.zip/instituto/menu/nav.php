<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>formulario </title>
    <link href="bootstrap-5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap-5.1.3/js/bootstrap.bundle.min.js"></script>
</head>



<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php?opcion=inicio">Home</a>
            <a class="navbar-brand" href="index.php?opcion=alta">creacion de las tablas</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDarkDropdown" aria-controls="navbarNavDarkDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
                <ul class="navbar-nav">
                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Alumnos
                        </a>
                        <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
                            <li><a class="dropdown-item" href="index.php?opcion=alumno">alta alumno</a></li>
                            <li><a class="dropdown-item" href="index.php?opcion=ver_t">tabla alumno</a></li>
                            <li><a class="dropdown-item" href="index.php?opcion=buscar">buscar alumno</a></li>
                        </ul>
                    </li>
                    
                </ul>
            </div>
        </div>
    </nav>
    </div>
</body>

</html>