<?php
require ('modelo/conexion.php');
//require ('Modelo/M_claseX.php');

Class C_frontal	{
    var $ctr="inicio";
	var $act=null;

//Capturamos a opción de menú escollida polo usuario.
	public function capturar_opcion(){
	  if($_GET){
	  	if(array_key_exists('act',$_GET)){
	  	  $this->ctr=$_GET['ctr'];
	 	  $this->act=$_GET['act'];;
	  	}
	  }
	  
	}

}


?>