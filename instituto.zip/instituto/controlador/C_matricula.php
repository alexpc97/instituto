<?php

require('modelo/matricula.php');

class C_matricula
{


    public function creartabla()
    {
        $obx = new matricula("", "");
        $obx->ALTA_BD();
    }
    public function alta()
    {
        require('vista/altamatricula.php');
        if (!empty($_POST['nombre']) && !empty($_POST['modulo'])) {

            $c2 = $_POST['nombre'];
            $c3 = $_POST['modulo'];

            $obX = new matricula($c2, $c3);

            $obX->matricular();
        }
    }
    static function VER_T()
    {
        $datos = matricula::VER_T();
        include('vista/tablamatricula.php');
    }
    public function eliminar()
    {
        $obX = new matricula($_GET['delete'], "");
        $obX->eliminar();
    }

    public function modificar($c)
    {
       include('vista/modifmatricula.php');
       if ( !empty($_POST['modulo'])) {
          $c2 = "";
          $c3 = $_POST['modulo'];

          $obX = new matricula($c2,$c3);

          $obX->modificar($c);

       }
    }
}
