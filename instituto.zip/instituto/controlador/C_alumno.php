 <?php



   require('modelo/alumno.php');


   class C_alumno
   {
      var $opcion;

      //Capturamos a opción de menú escollida polo usuario.
      public function capturar_opcion()
      {
         $opcion = '';
         if ($_GET) {
            if (array_key_exists('opcion', $_GET)) {
               $opcion = $_GET['opcion'];
            }
         }
         $this->opcion = $opcion;
      }

      public function creartabla()
      {
         $c2 = "";
         $c3 = "";
         $obX = new alumno($c2, $c3);

         $obX->ALTA_BD();
      }


      public function alta()
      {
         require('vista/alta.php');
         if (!empty($_POST['nombre']) && !empty($_POST['nota'])) {

            $c2 = $_POST['nombre'];
            $c3 = $_POST['nota'];

            $obX = new alumno($c2,$c3);

            $obX->guardaralumno();
         }
      }


      
      static function VER_T()
      {
         $datos = alumno::VER_T();
         include('vista/tabla.php');
      }

      static function buscar()
      {

         // $datos = alumno:: buscaralumno();
         // include ('VISTA/tabla2.php');

         include('vista/buscar.php');
         if (isset($_POST['nombre']) ) {
          
            $c2 = $_POST['nombre'];
            $c3 = "";

            $obX = new alumno($c2, $c3);

            $datos = $obX->buscaralumno();
            include('vista/tabla.php');
         }
      }



      public function eliminar()
      {
         $obX = new alumno($_GET['delete'],"");
         $obX->eliminar();
      }


      public function modificar($c)
      {
         include('vista/alta.php');
         if ( !empty($_POST['nombre']) && !empty($_POST['nota'])) {
            $c2 = $_POST['nombre'];
            $c3 = $_POST['nota'];

            $obX = new alumno($c2,$c3);

            $obX->modificar($c);

         }
      }
   }
