<?php



require('modelo/modulo.php');


class C_modulo
{
   var $opcion;

   //Capturamos a opción de menú escollida polo usuario.
   public function capturar_opcion()
   {
      $opcion = '';
      if ($_GET) {
         if (array_key_exists('opcion', $_GET)) {
            $opcion = $_GET['opcion'];
         }
      }
      $this->opcion = $opcion;
   }

   public function creartabla()
   {
      $c2 = "";
      $c3 = "";
      $obX = new modulo($c2, $c3);

      $obX->ALTA_BD();
   }


   public function alta()
   {
      require('vista/altamodulo.php');
      if (!empty($_POST['descripcion']) && !empty($_POST['horas'])) {

         $c2 = $_POST['descripcion'];
         $c3 = $_POST['horas'];

         $obX = new modulo($c2,$c3);

         $obX->guardarmodulo();
      }
   }


   
   static function VER_T()
   {
      $datos = modulo::VER_T();
      include('vista/tabla2.php');
   }

 



   public function eliminar()
   {
      $obX = new modulo($_GET['delete'],"");
      $obX->eliminar();
   }


   public function modificar($c)
   {
      include('vista/altamodulo.php');
      if ( !empty($_POST['descripcion']) && !empty($_POST['horas'])) {
         $c2 = $_POST['descripcion'];
         $c3 = $_POST['horas'];

         $obX = new modulo($c2,$c3);

         $obX->modificar($c);

      }
   }
}
