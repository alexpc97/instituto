<?php
// --------------------------------PARA DOS CLASES---------------------------------

require('menu/nav2.php');
require('controlador/Co_frontal.php');

$frontal = new C_frontal();
$frontal->capturar_opcion();

if ($frontal->ctr == 'inicio') {
    // require('index.php');
} else {
    $clase = $frontal->ctr;
    $controlador = $clase . '.php';

    require('controlador/' . $controlador);
    $obx_X = new $clase();

    switch ($frontal->act) {
        case 'alta':
            $obx_X->creartabla();
            break;
        case 'alumno':
            $obx_X->alta();
            break;
        case 'ver_t':
            $obx_X->VER_T();
            break;
        case 'buscar':
            $obx_X->buscar();
            break;
        case 'eliminar':
            $obx_X->eliminar();
            break;
        case 'modificar':
            $obx_X->modificar();
            break;
        case 'inicio':
            require('VISTA/home.html');
            break;
        default:
            # code...
            break;
    }

    


}









// ---------------------------PARA UNA SOLA CLASE------------------------------------  

// require('modelo/conexion.php');
// require('menu/nav.php');
// require('controlador/C_alumno.php ');
// $obx_X = new C_alumno();

// $obx_X->capturar_opcion();



// $url=$_SERVER['REQUEST_URI'];
// $archivo = basename($url);
// if($archivo=='index.php')
//     require('VISTA/home.html');

// switch ($obx_X->opcion) {
//     case 'alta':
//         $obx_X->creartabla();
//         break;
//     case 'alumno':
//         $obx_X->alta();
//         break;
//     case 'ver_t':
//         $obx_X->VER_T();
//         break;
//     case 'buscar':
//         $obx_X->buscar();
//         break;
//     case 'eliminar':
//         $obx_X->eliminar();
//         break;
//     case 'modificar':
//         $obx_X->modificar();
//         break;
//         case 'inicio':
//             require('VISTA/home.html');
//             break;	
//     default:
//         # code...
//         break;
// }
