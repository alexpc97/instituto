<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <form action="" method="post">

        <div class="container mt-3">
            <h1>Matricula</h1>
            <form action="#" method="POST">

                <div class="mb-3">
                    <label>alumno :</label>
                    <input type="text" class="form-select"  name="nombre"  value="<?php echo $_GET['nom']?>" disabled>
                </div>
                <div class="mb-3">
                    <label>modulos :</label>
                    <select name="modulo" id="" class="form-select">
                        <?php
                        $connect = new conexion;
                        $query = "select * from modulos";
                        $result = $connect->con->query($query);

                        if ($result->num_rows > 0) {
                            echo "i";
                            while ($filas = $result->fetch_array()) {
                                echo "<option value = " . $filas['cod'] . ">" . $filas['descripcion'] . "</option>";
                            }
                        } else {
                            echo 'no hay resultados';
                        }
                        ?>

                    </select>
                </div>
                <button type="submit" name="enviar" class="btn btn-primary">guardar</button>

            </form>
        </div>



    </form>

</body>

</html>