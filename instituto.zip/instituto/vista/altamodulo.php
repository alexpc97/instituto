<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar</title>
</head>

<body>
    <div class="container mt-3">
        <h1>alta modulo</h1>
        <form action="#" method="POST">

            <div class="mb-3">
                <label>descripcion :</label>
                <input type="text" class="form-control" name="descripcion">
            </div>
            <div class="mb-3">
                <label>horas :</label>
                <input type="number" class="form-control" name="horas">
            </div>
            <button type="submit" name="enviar" class="btn btn-primary">guardar</button>

        </form>
    </div>
</body>

</html>