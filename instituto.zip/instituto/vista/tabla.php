<!DOCTYPE html>
<html>

<head>
    <title>Listado datos</title>

    <style>
        tr {
            text-align: center;
        }
    </style>
    <?php

    $p = new C_alumno();
    if (isset($_GET['delete'])) {
        $p->eliminar();
        header("Refresh:0; url=index.php?ctr=C_alumno&act=ver_t");
        exit;
    } elseif (isset($_GET['edit'])) {
        $c = $_GET['edit'];
        $p->modificar( $c);

    }



    ?>
</head>

<body>
    <h1 style="text-align: center;">Tablas Alumnos</h1>

    <div class="container">

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">cod</th>
                    <th scope="col">nome</th>
                    <th scope="col">nota</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($datos as $valor) {

                ?>
                    <tr>

                        <td><?php echo  $valor['cod'];  ?></td>
                        <td><?php echo  $valor['nome'];  ?></td>
                        <td><?php echo  $valor['nota'];  ?></td>
                        <td>
                            <a href="index.php?ctr=C_alumno&act=ver_t&edit=<?php echo  $valor['cod']; ?>" class="btn btn-info ">edit </a>


                        </td>
                        <td>

                            <a href="index.php?ctr=C_alumno&act=ver_t&delete=<?php echo  $valor['nome']; ?>" class="btn btn-danger">delete </a>
                        </td>

                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

</body>

</html>