<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>modificar </title>

</head>

<body>

  
    <div class="container mt-3">
        <h1>alta alumno</h1>
        <form action="#" method="POST">

            <div class="mb-3">
                <label>Nombre :</label>
                <input type="text" class="form-control" name="nombre">
            </div>
            <div class="mb-3">
                <label>Nota :</label>
                <input type="number" class="form-control" name="nota">
            </div>
            <button type="submit" name="enviar" class="btn btn-primary">guardar</button>

        </form>
    </div>
</body>

</html>