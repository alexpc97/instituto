<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar</title>
</head>

<body>
    <div class="container mt-3">
        <h1>buscar alumnos</h1>
        <form action="#" method="POST">

            <div class="mb-3">
                <label>nome :</label>
                <input type="text" class="form-control" name="nombre">
            </div>
            <button type="submit" name="enviar" class="btn btn-primary">buscar</button>

        </form>
    </div>
</body>

</html>