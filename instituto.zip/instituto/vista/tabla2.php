<!DOCTYPE html>
<html>

<head>
    <title>Listado datos</title>
    <style>
        tr {
            text-align: center;
        }
    </style>
    <?php

    $p = new C_modulo();
    if (isset($_GET['delete'])) {
        $p->eliminar();
        header("Refresh:0; url=index.php?ctr=C_modulo&act=ver_t");
        exit;
    } elseif (isset($_GET['edit'])) {
        $c = $_GET['edit'];
        $p->modificar($c);
        // header("Refresh:0; url=index.php?opcion=ver_t");
        // exit;
    }



    ?>
</head>

<body>
    <h1 style="text-align: center;">Tablas modulos </h1>

    <div class="container">

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">cod</th>
                    <th scope="col">descripcion</th>
                    <th scope="col">horas</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($datos as $valor) {

                ?>
                    <tr>

                        <td><?php echo  $valor['cod'];  ?></td>
                        <td><?php echo  $valor['descripcion'];  ?></td>
                        <td><?php echo  $valor['horas'];  ?></td>
                        <td>
                            <a href="index.php?ctr=C_modulo&act=ver_t&edit=<?php echo  $valor['cod']; ?>" class="btn btn-info ">edit </a>


                        </td>
                        <td>

                            <a href="index.php?ctr=C_modulo&act=ver_t&delete=<?php echo  $valor['descripcion']; ?>" class="btn btn-danger">delete </a>
                        </td>

                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

</body>

</html>